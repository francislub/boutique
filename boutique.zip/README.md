# boutique
### Business System User Functions  Based on the inventory management system sketch you've provided, here's a breakdown of functions for each user role:
